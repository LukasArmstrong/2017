/*********************************/
/*     G. Lukas J. Armstrong     */
/*          CECS 130-02          */
/*         Assignment 02         */
/*********************************/
#include <stdio.h>
int main(){
  int a, b, x, y;
  printf("Enter an integer value for the following values.\n");
  printf("a:");
  scanf("%d",&a);
  printf("\nb:");
  scanf("%d",&b);
  printf("\nx:");
  scanf("%d",&x);
  printf("\ny:");
  scanf("%d",&y);
  int f = (a-b)*(x-y);
  printf("With the following values: a = %d, b = %d, x = %d, y = %d, and the equation f = (a-b)*(x-y). Your anwser is %d",a,b,x,y,f);
  return 0;
}
