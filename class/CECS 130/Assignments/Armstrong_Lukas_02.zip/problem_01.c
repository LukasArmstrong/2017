/*********************************/
/*     G. Lukas J. Armstrong     */
/*          CECS 130-02          */
/*         Assignment 02         */
/*********************************/
#include <stdio.h>
int main(){
  int a = 5, b = 1, x = 10, y = 5;
  int f = (a-b)*(x-y);
  printf("%d",f);
  return 0;
}
