/*********************************/
/*     G. Lukas J. Armstrong     */
/*          CECS 130-02          */
/*         Assignment 01         */
/*********************************/
#include <stdio.h>
int main(){
  printf("\"   Never argue with stupid people,\n");
  printf(" they will drag you down to their level \n");
  printf("\t\t and \n");
  printf("      beat you with experience.     \"");
  return 0;
}
