/*********************************/
/*     G. Lukas J. Armstrong     */
/*          CECS 130-02          */
/*         Assignment 01         */
/*********************************/
#include <stdio.h>
int main(){
  printf("\t\t\t*\n");
  printf("\t\t*\t\t*\n");
  printf("\t*\t\t\t\t*\n");
  printf("*\t\t\t\t\t\t*\n");
  printf("\t*\t\t\t\t*\n");
  printf("\t\t*\t\t*\n");
  printf("\t\t\t*\n");
  return 0;
}
